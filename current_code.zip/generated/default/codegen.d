C:/Users/e4ekhan/Documents/GitHub/SegaSuperstarsTennisRecomp/generated/default/codegen.build.stamp: \
  C:/Users/e4ekhan/Documents/GitHub/SegaSuperstarsTennisRecomp/assets/default.xex \
  C:/Users/e4ekhan/Documents/GitHub/SegaSuperstarsTennisRecomp/config/sst_rematch_func.toml \
  C:/Users/e4ekhan/Documents/GitHub/SegaSuperstarsTennisRecomp/sst_rematch_manifest.toml
