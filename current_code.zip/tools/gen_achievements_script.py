"""Generates src/menu/achievements_script.inc: the script that replaces the
game's "options_achievements" script (Options > ACHIEVEMENTS). On the Xbox 360
that script only faded out, opened the system's achievements UI and faded
back. The port's version shows the RECORDS page of the main menu scene with
the achievement list the port adds to it (src/menu/achievements.cpp, scene
patch in scene_widen.cpp) instead of the records:

  begin()  (native 0x41:0) -> scroll steps (rows - visible rows, 0 if all fit);
                              fills the rows' texts, icons and dimming and
                              shows the list and the summary
  finish() (native 0x41:1)    hides them again (Exit)

The page's entry and exit (white fade, page and background, navbar) follow
the game's own options_records script. Up / down scroll one row; the records'
scroll thumb and arrows follow. Back returns to the main menu.

  python tools/gen_achievements_script.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sbn_asm import (Asm, jhash, module, OP_ADD, OP_SUB, OP_LT, OP_GT, OP_EQ,  # noqa: E402
                     OP_DIV, OP_TOFLOAT)

# --- RECORDS page (SSTMainMenu) ---
PAGE_RECORDS = 0x487BEEA2        # page (4:2 / 4:3)
PAGE_BACKDROP = 0xA0BB520B       # the options' backdrop page
BACKDROP_ANIM = (0xED8B78BF, 0x4240C67E, 0x4240C67E)  # 4:9 loop on entry
HIDE_ON_ENTRY = [0x22CD7281, 0x9B7FA24A, 0xC63404CD]  # backdrop parts the records page hides
ARROWS, MAIN, TRACK = 0x3786CA87, 0x07C39636, 0xEAD84AE2
THUMB = 0x8FC4C747
CONTENT, ONLINE_CONTENT, TABS = 0x165C0375, 0x1E0FA635, 0xDAE5109B
INTRO_A, INTRO_B = 0xB2244A6D, 0x02F0B24C
TOP, BOTTOM = 0xD32C49F0, 0x03CCAD8D
ARROW_UP = (0x283F3748, 0xD89ACF4D)
ARROW_DOWN = (0x5F43A7CB, 0x1F55A1BE)
TITLE, TITLE_RECORDS, TXT_ACHIEVEMENTS = 0xECC2F67F, 0x5EAA11FF, 0x32092476
LIST = 0x53410001                # the port's list group (achievements.cpp kList)
LIST_PAGE = 0x53410000           # its page (with the summary text), entered with the RECORDS page
FADE_IN = (0x5E391A57, 0x28C201E8)  # the list's keys: transparent (frame 0) -> shown (frame 26)

WHT_FADE = jhash("WHT_FADE\\WHT_FADE")
FADE_START, FADE_END = jhash("WHT_FADE_30FRAMES_START"), jhash("WHT_FADE_30FRAMES_END")
LOOP_END = jhash("LOOP_END")
FADE_FLAG = 0x7B02CF4D           # global the options scripts set while fading
NAVBAR_CLEAR, NAVBAR_BUTTONS, NAVBAR_EXTRA = 0x3E6994DF, 0x69F54F57, 0x62FD7EA3
TXT_BACK = 0x3A648438
INPUT = 0x7074624C
EV_UP, EV_DOWN, EV_BACK = 0xB0A4EB7F, 0xA3AD84E1, 0xA979AAA1
SCRIPT_MAINMENU = jhash("mainmenu")

G = 0x41
N_BEGIN, N_FINISH = 0, 1

S_RETURN, S_STEPS, S_POS, S_ALPHA = 0, 1, 2, 3
NSLOTS = 4


def build():
    a = Asm()

    def call(group, idx, argc, keep=False):
        a.native(group, idx, argc)
        if not keep:
            a.pop()

    def h(v):
        a.pushh(v)

    def show(obj, on=True):
        h(obj)
        call(4, 4 if on else 5, 1)

    def anim(obj, k1, k2, loop=0):
        h(obj); h(k1); h(k2); a.pushi(loop)
        call(4, 10, 4)

    def sound(name):
        a.pushh(jhash(name))
        call(7, 1, 1)

    def scroll():
        # 4:14(object, top key, bottom key, position / steps) for the list and the thumb
        for obj in (LIST, THUMB):
            h(obj); h(TOP); h(BOTTOM)
            a.pushabs(S_POS); a.op(OP_TOFLOAT)
            a.pushabs(S_STEPS); a.op(OP_TOFLOAT)
            a.op(OP_DIV)
            call(4, 14, 4)

    # ---------------- entry (as options_records) ----------------
    a.pushi(0); a.stabs(S_RETURN)
    a.pushi(0); a.stabs(S_POS)
    h(PAGE_RECORDS); call(4, 2, 1)
    h(LIST_PAGE); call(4, 2, 1)
    a.pushnil(); a.yield_()
    # 3:0(0.3) as the records page does
    a._b(0x03); a._u32(0x3E99999A)  # pushf 0.3
    call(3, 0, 1)
    h(PAGE_BACKDROP); call(4, 2, 1)
    h(BACKDROP_ANIM[0]); h(BACKDROP_ANIM[1]); h(BACKDROP_ANIM[2]); h(LOOP_END); a.pushi(0)
    call(4, 9, 5)
    for obj in HIDE_ON_ENTRY + [ARROWS, MAIN, TRACK]:
        show(obj, False)
    a.pushnil(); a.yield_()
    a._b(0x03); a._u32(0x3E99999A)
    call(3, 0, 1)
    # From white: the fade's alpha 255 -> 0
    show(WHT_FADE)
    a.pushi(255); a.stabs(S_ALPHA)
    a.pushi(0); a.setgh(FADE_FLAG)
    fade = a.here("fade_in")
    a.pushabs(S_ALPHA); a.pushi(0); a.op(OP_GT); a.jf("faded_in")
    a.pushabs(S_ALPHA); a.pushi(9); a.op(OP_SUB); a.stabs(S_ALPHA)
    clamp = a.label()
    a.pushabs(S_ALPHA); a.pushi(0); a.op(OP_LT); a.jf(clamp)
    a.pushi(0); a.stabs(S_ALPHA)
    a.here(clamp)
    h(WHT_FADE); a.pushabs(S_ALPHA); a.op(3)  # touint
    call(4, 18, 2)
    a.pushi(0); a.yield_()
    a.jmp(fade)
    a.here("faded_in")
    # Navbar: Back only
    h(NAVBAR_CLEAR); a.pushi(0); a.pushnil(); call(2, 5, 3)
    h(NAVBAR_BUTTONS); a.pushi(0); a.pushi(2); a.pushh_raw(TXT_BACK); a.array(2); call(2, 5, 3)
    h(NAVBAR_EXTRA); a.pushi(0); a.pushi(0); a.pushnil(); a.array(2); call(2, 5, 3)
    # Title, list instead of the records
    h(TITLE); h(TXT_ACHIEVEMENTS); call(4, 15, 2)
    call(G, N_BEGIN, 0, keep=True)
    a.stabs(S_STEPS)
    for obj in (ARROWS, MAIN, TRACK):
        anim(obj, INTRO_A, INTRO_B)
        show(obj)
    # (after showing the records group: showing a group shows its children)
    for obj in (CONTENT, ONLINE_CONTENT, TABS):
        show(obj, False)
    anim(LIST, FADE_IN[0], FADE_IN[1])
    # Nothing to scroll: no arrows or thumb
    scrolls = a.label()
    a.pushabs(S_STEPS); a.pushi(0); a.op(OP_GT); a.jt(scrolls)
    for obj in (ARROWS, THUMB, TRACK):
        show(obj, False)
    a.here(scrolls)

    # ---------------- main loop ----------------
    loop = a.here("loop")
    a.pushh_raw(INPUT)
    a.native(3, 6, 1)  # event (kept on the stack until the end of the frame)
    # up
    nxt = a.label()
    a.dup(1); a.pushi(EV_UP); a.op(OP_EQ); a.jf(nxt)
    a.pushabs(S_POS); a.pushi(0); a.op(OP_GT); a.jf(nxt)
    a.pushabs(S_POS); a.pushi(1); a.op(OP_SUB); a.stabs(S_POS)
    anim(ARROWS, ARROW_UP[0], ARROW_UP[1])
    anim(ARROWS, ARROW_UP[1], ARROW_UP[0])
    scroll()
    sound("Move")
    a.here(nxt)
    # down
    nxt = a.label()
    a.dup(1); a.pushi(EV_DOWN); a.op(OP_EQ); a.jf(nxt)
    a.pushabs(S_POS); a.pushabs(S_STEPS); a.op(OP_LT); a.jf(nxt)
    a.pushabs(S_POS); a.pushi(1); a.op(OP_ADD); a.stabs(S_POS)
    anim(ARROWS, ARROW_DOWN[0], ARROW_DOWN[1])
    anim(ARROWS, ARROW_DOWN[1], ARROW_DOWN[0])
    scroll()
    sound("Move")
    a.here(nxt)
    # back
    nxt = a.label()
    a.dup(1); a.pushi(EV_BACK); a.op(OP_EQ); a.jf(nxt)
    sound("Back")
    a.pop()
    a.jmp("done")
    a.here(nxt)
    a.pushi(0)
    a.yield_()
    a.pop()
    a.jmp(loop)

    # ---------------- leave: fade to white, back to the main menu ----------------
    a.here("done")
    a.pushi(1); a.setgh(FADE_FLAG)
    h(WHT_FADE); call(4, 49, 1)
    show(WHT_FADE)
    anim(WHT_FADE, FADE_START, FADE_END)
    h(WHT_FADE); call(4, 12, 1)
    h(WHT_FADE); h(FADE_END); h(FADE_END); h(LOOP_END); a.pushi(0)
    call(4, 9, 5)
    h(NAVBAR_CLEAR); a.pushi(0); a.pushnil(); call(2, 5, 3)
    a.pushi(1); a.stabs(S_RETURN)
    a.end()

    # ---------------- Exit (called when the script is stopped) ----------------
    a.here("exit")
    call(G, N_FINISH, 0)
    h(TITLE); h(TITLE_RECORDS); call(4, 15, 2)
    for obj in (CONTENT, TABS):
        show(obj)
    h(LIST_PAGE); call(4, 3, 1)
    h(PAGE_RECORDS); call(4, 3, 1)
    h(PAGE_BACKDROP); call(4, 3, 1)
    a.pushabs(S_RETURN)
    a.jf("exit_done")
    a.pushh(SCRIPT_MAINMENU)
    a.pushh_raw(0)
    call(3, 1, 2)
    a.here("exit_done")
    a.pushnil()
    a.ret()

    return module(a, {"Exit": "exit"}, NSLOTS, "sst:options_achievements.smos")


def main():
    blob = build()
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "src", "menu", "achievements_script.inc")
    lines = ["// Generated by tools/gen_achievements_script.py - do not edit.",
             f"// {len(blob)} bytes: replacement for the game's \"options_achievements\" script.",
             "static const uint8_t kAchievementsScript[] = {"]
    for i in range(0, len(blob), 16):
        lines.append("    " + ", ".join(f"0x{b:02X}" for b in blob[i:i + 16]) + ",")
    lines.append("};")
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print(f"wrote {out} ({len(blob)} bytes)")
    return blob


if __name__ == "__main__":
    main()
