"""Assembler for Sega Superstars Tennis front-end scripts (fescripts.sbn).

The game's SumoTool scripts are bytecode for a small stack VM (interpreter at
sub_825DBBE8, natives dispatched by sub_821DFBC0). This module builds new
script modules for that VM; it contains no game data, only the instruction
encoding (see claude/ingame-menu-re.md in the project for the opcode list).

Module layout (big-endian), offsets from the module start:
  0x00 u32 code offset (0x20)       0x10 u32 0x20
  0x04 u32 function table offset    0x14 u32 source file hash
  0x08 u32 table 2 offset           0x18 u32 number of absolute slots
  0x0C u32 global symbol table (0)  0x1C u32 debug info offset
Function table: u32 count, then {u32 name hash, u32 offset from code start}.
Names are Bob Jenkins' lookup2 hash, initval 0x04C11DB7.
"""

import struct

M32 = 0xFFFFFFFF


def _mix(a, b, c):
    a = (a - b - c) & M32; a ^= c >> 13
    b = (b - c - a) & M32; b ^= (a << 8) & M32
    c = (c - a - b) & M32; c ^= b >> 13
    a = (a - b - c) & M32; a ^= c >> 12
    b = (b - c - a) & M32; b ^= (a << 16) & M32
    c = (c - a - b) & M32; c ^= b >> 5
    a = (a - b - c) & M32; a ^= c >> 3
    b = (b - c - a) & M32; b ^= (a << 10) & M32
    c = (c - a - b) & M32; c ^= b >> 15
    return a, b, c


def jhash(key, initval=0x04C11DB7):
    """lookup2 hash, as sub_825DE510."""
    if isinstance(key, str):
        key = key.encode("latin1")
    n = len(key)
    a = b = 0x9E3779B9
    c = initval
    i = 0
    left = n
    while left >= 12:
        a = (a + int.from_bytes(key[i:i + 4], "little")) & M32
        b = (b + int.from_bytes(key[i + 4:i + 8], "little")) & M32
        c = (c + int.from_bytes(key[i + 8:i + 12], "little")) & M32
        a, b, c = _mix(a, b, c)
        i += 12
        left -= 12
    c = (c + n) & M32
    t = key[i:]
    for idx, (reg, shift) in reversed(list(enumerate(
            [("a", 0), ("a", 8), ("a", 16), ("a", 24), ("b", 0), ("b", 8), ("b", 16), ("b", 24),
             ("c", 8), ("c", 16), ("c", 24)]))):
        if left > idx:
            v = t[idx] << shift
            if reg == "a":
                a = (a + v) & M32
            elif reg == "b":
                b = (b + v) & M32
            else:
                c = (c + v) & M32
    a, b, c = _mix(a, b, c)
    return c


# Binary operators (operand of op 0x0D); unary ones are 0..8.
OP_TOFLOAT, OP_TOINT, OP_TOHASH = 2, 3, 4
OP_HASH = 6  # applied to every hash literal before it is passed on
OP_NOT = 7
OP_MUL, OP_DIV, OP_ADD, OP_SUB = 9, 10, 12, 13
OP_LT, OP_GT, OP_GE, OP_EQ, OP_NE = 16, 18, 19, 20, 21


class Asm:
    def __init__(self):
        self.code = bytearray()
        self.labels = {}
        self.fixups = []  # (pos, size, label, base)
        self._n = 0

    def label(self, name=None):
        if name is None:
            self._n += 1
            name = f"_L{self._n}"
        return name

    def here(self, name):
        assert name not in self.labels, name
        self.labels[name] = len(self.code)
        return name

    def _b(self, *vals):
        self.code += bytes(vals)

    def _u16(self, v):
        self.code += struct.pack(">H", v & 0xFFFF)

    def _i16(self, v):
        self.code += struct.pack(">h", v)

    def _u32(self, v):
        self.code += struct.pack(">I", v & M32)

    # --- stack ---
    def pushi(self, v):
        self._b(0x01); self._u32(v)

    def pushh(self, h):
        """Hash literal, converted like the compiler does (op 6)."""
        self._b(0x02); self._u32(h); self._b(0x0D, OP_HASH)

    def pushh_raw(self, h):
        self._b(0x02); self._u32(h)

    def pushnil(self):
        self._b(0x31)

    def pop(self):
        self._b(0x18)

    def dup(self, n=1):
        """Copy of the value n slots from the top (1 = top)."""
        self._b(0x07, n)

    def pushabs(self, slot):
        self._b(0x29); self._i16(slot)

    def stabs(self, slot):
        self._b(0x27); self._i16(slot)

    def pushgh(self, h):
        self._b(0x2F); self._u32(h)

    def setgh(self, h):
        self._b(0x2D); self._u32(h)

    def op(self, o):
        self._b(0x0D, o)

    def index(self):
        """arr idx -> arr[idx]"""
        self._b(0x23)

    def array(self, n):
        """Pops n values into a new array (first pushed = element 0)."""
        self._b(0x22); self._u32(n)

    # --- calls ---
    def native(self, group, idx, argc):
        self._b(0x12, argc); self._u16((group << 8) | idx)

    def yield_(self):
        """Pops one value and suspends until the next frame."""
        self._b(0x1D)

    def ret(self):
        self._b(0x1B)

    def end(self):
        self._b(0x00)

    # --- control flow (relative to the end of the instruction) ---
    def _jump(self, opc, label):
        self._b(opc)
        self.fixups.append((len(self.code), 2, label))
        self._i16(0)

    def jmp(self, label):
        self._jump(0x15, label)

    def jt(self, label):
        self._jump(0x13, label)

    def jf(self, label):
        self._jump(0x14, label)

    def finish(self):
        for pos, size, label in self.fixups:
            if label not in self.labels:
                raise KeyError(f"undefined label {label}")
            rel = self.labels[label] - (pos + size)
            assert -0x8000 <= rel < 0x8000, label
            struct.pack_into(">h", self.code, pos, rel)
        self.fixups = []
        return bytes(self.code)


def module(asm, functions, slots, source_name):
    """functions: {name: label}. Returns the module bytes."""
    code = asm.finish()
    code_off = 0x20
    body = bytearray(code)
    while len(body) % 4:
        body.append(0x11)  # nop
    functab_off = code_off + len(body)
    funcs = sorted((jhash(n), asm.labels[l]) for n, l in functions.items())
    ft = struct.pack(">I", len(funcs)) + b"".join(struct.pack(">II", h, o) for h, o in funcs)
    tab2_off = functab_off + len(ft)
    t2 = struct.pack(">I", 0)
    debug_off = tab2_off + len(t2)
    name = source_name.encode("latin1") + b"\0"
    dbg = struct.pack(">I", debug_off + 4) + name
    while len(dbg) % 4:
        dbg += b"\0"
    header = struct.pack(">8I", code_off, functab_off, tab2_off, 0, 0x20, jhash(source_name),
                         slots, debug_off)
    return header + bytes(body) + ft + t2 + dbg
