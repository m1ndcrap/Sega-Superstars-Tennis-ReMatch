"""Generates src/menu/graphics_script.inc: the script that replaces the game's
"video" script (Options > Settings > VIDEO) with the port's VIDEO page (and,
started from the CONTROLS page, its KEY BINDINGS page).

The page reuses the scene layout of Settings > GENERAL (four rows, a cursor
and highlight animations) as a scrolling window onto the port's list of
settings. The list, the values and the texts live in C++
(src/menu/graphics_menu.cpp, native group 0x53); the script only forwards
input events and redraws what the natives tell it to:
  begin()                    -> visible cursor row
  event(code)                   (left, right, up, down, select, back = 0-5)
  result(k)                  -> after an event: k 0 old cursor row, 1 new
                                cursor row, 2 redraw texts, 3 leave the page,
                                4 sound (0 none, 1 move, 2 select, 3 back)
  label(row) / value(row)    -> text id for visible row 0-3
  result(5)                  -> 1: show the restart dialog (ASPECT RATIO 4:3 switched),
                                then restart() (native 9) restarts the game
Value texts are drawn into each row's first value object (rows stay at value
0 visually; the per-value slide animations are not used).

  python tools/gen_graphics_script.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sbn_asm import (Asm, jhash, module, OP_ADD, OP_SUB, OP_LT, OP_GT, OP_EQ)  # noqa: E402

# --- scene objects / keyframe labels (Settings > GENERAL page, SSTMainMenu) ---
PAGE_GENERAL = 0x6A94D0C1        # page id (4:2 enter, 4:3 leave)
PAGE_ROWS_LAYER = 0x6BCD2893     # shown on entry (4:5)
CURSOR = 0xAF90E2C8
CURSOR_INTRO = 0xB2244A6D
ROWS = [0xDA2F6C3D, 0xA6BE1C59, 0xA696DBE4, 0x74D374C2]
STATES = [3, 3, 2, 2]
CURSOR_KEYS = [0xAFF91553, 0x417E03CC, 0xFFB6C545, 0x4318364C, 0x5449808B]
INIT_A = [[0xA7F74AE3, 0x5EE4D5FB, 0xA71FDD85], [0x5D25743F, 0x07D5266C, 0x77C4533B],
          [0x6DC16273, 0x3260661E], [0x3610F23B, 0xBDFA0668]]
INIT_B = [[0x8B9C1763, 0x18AB5168, 0x3D6167C1], [0x0ACD7A07, 0xB7E6FA51, 0x0967F9E2],
          [0x62F057BE, 0xA94FCE10], [0xC8B92F22, 0x6A8A5824]]
TRANS = [[0x3EFB1A14, 0x82E08EFB, 0x6FBF2512, 0x332D8A48],
         [0x06FA0220, 0x3F7FF400, 0x61D11F4C, 0x4BF4886A],
         [0x30CDA576, 0x32440610, 0xA7E5981B],
         [0x703EA7D1, 0xB6BD8719, 0x17CA40F7]]
HL_A = [[0x2D51209B, 0xAA80CD2A, 0x815FE4D1], [0x88F27E71, 0x17391E7D, 0x0DE79741],
        [0x35B10DFB, 0x46C3D793], [0x0B5D2A77, 0xB3F18848]]
HL_B = [[0x0E259128, 0x3E6146F5, 0xFB71D0B2], [0x2F00C88E, 0x933CD556, 0xA9C5479A],
        [0xFBB9D706, 0x4069BE11], [0x1406EBC3, 0xE1401D18]]
NAVBAR_CLEAR, NAVBAR_BUTTONS, NAVBAR_EXTRA = 0x3E6994DF, 0x69F54F57, 0x62FD7EA3
TXT_SELECT, TXT_CONFIRM, TXT_BACK = 0xF1141A0A, 0xFBD92248, 0x3A648438
INPUT = 0x7074624C
EV_LEFT, EV_RIGHT, EV_UP, EV_DOWN = 0xF5BF6BF3, 0x5856F909, 0xB0A4EB7F, 0xA3AD84E1
EV_SELECT, EV_BACK = 0x2FAB294A, 0xA979AAA1
SETTINGS_CURSOR = 0x38CCCFAA     # global: Settings list cursor + 1
VIDEO_ITEM = 5                   # VIDEO is item 4 of Settings
SCRIPT_SETTINGS = jhash("options_settings")

# Natives the port adds (group 0x53).
G = 0x53
N_BEGIN, N_EVENT, N_LABEL, N_VALUE, N_RESULT = 0, 1, 2, 3, 4
N_RESTART = 9  # 5-8: the in-match pause page (pause_patch.h)
# The same page also serves CONTROLS > KEY BINDINGS (the C++ side picks the
# list when the page opens); these natives make the script list-agnostic:
N_TITLE = 18          # -> title text id
N_FRAME = 19          # every frame -> 1: redraw (a key binding was captured)
N_RETURN_CURSOR = 20  # -> Settings list cursor + 1 to leave behind
N_RETURN_SCRIPT = 21  # -> script to start on leaving (hash)
# Settings > GENERAL (the same page with the GENERAL list) has five rows on screen when the
# scene has its fifth row (src/menu/scene_rows.cpp AddGeneralRow): a copy of the SPEED row one
# row lower, with its own stretch of the cursor's timeline. The four-row lists hide it.
N_ROWS = 22           # -> rows on screen (4 or 5)
N_CURSOR_KEY = 23     # (k) cursor animation: 0 from key, 1 to key (after an event), 2 the start row's key
ROW5_BAR, ROW5_VALUES = 0x53474E01, 0x53474E02    # src/menu/menu_internal.h kGeneral*
ROW5_LABEL, ROW5_VALUE = 0x53474E03, 0x53474E04

# The game's message box (script "msgbox", always running; main starts it):
# set the message id and the flags main sets, then wait for the id to clear.
MSGBOX_ID = 0x1473B103      # global: message to show (cleared when dismissed)
MSGBOX_FLAGS = [(0x94557658, 1), (0xDD766DAB, 1), (0xD0CA61AA, 1), (0x100F3079, -1)]
MSG_OK = 0x9C9008AD         # a one-button (OK) message (no longer used)
MSG_YES_NO = 0x3AE99363     # the YES / NO message the QUIT dialog uses; its texts are swapped by the port
MSGBOX_CHOICE = 0x65AEA351  # global: the button chosen (NO 0, YES 1)
N_RESTART_CANCEL = 24       # the dialog was answered NO: the restart-only settings go back, the page stays
EVENTS = [EV_LEFT, EV_RIGHT, EV_UP, EV_DOWN, EV_SELECT, EV_BACK]  # codes 0-5

TITLE, TITLE_ORIG = 0xDEC9DE35, 0x6A94D0C1
TXT_VIDEO = 0x5458AA85  # the game's own "VIDEO"
LABELS = [0x01C66D36, 0x981D79BE, 0x62DE61C6, 0x0DD05B3A, ROW5_LABEL]
LABELS_ORIG = [0x17E129F2, 0x6DD403F0, 0x8302CC03, 0x0880BE5D]
# Value object shown at value 0 (two-value rows show their second object).
VALUE_OBJS = [0x84383A9D, 0x2A0D35CF, 0x50DB65BA, 0x9BCCFC3F, ROW5_VALUE]
NROWS = 5  # rows the script draws (the fifth is hidden on the four-row lists)
VALUE_ORIG = [0x7F0D720B, 0x1D2E9662, 0x30A031AF, 0xE253D66D]

# Absolute slots.
S_EXIT, S_RETURN, S_OLD, S_NEW, S_RES = 0, 1, 2, 3, 4  # S_RES unused
S_ROWS, S_CUR, S_HLA, S_HLB = 5, 6, 7, 8
NSLOTS = 9


def build():
    a = Asm()

    def call(group, idx, argc, keep=False):
        a.native(group, idx, argc)
        if not keep:
            a.pop()

    def sound(name):
        a.pushh(jhash(name))
        call(7, 1, 1)

    def anim(obj, k1, k2, loop=0):
        obj()
        k1()
        k2()
        a.pushi(loop)
        call(4, 10, 4)

    def const_array(slot, values):
        for v in values:
            a.pushh_raw(v)
        a.array(len(values))
        a.stabs(slot)

    def at(arr, idx_slot):
        def f():
            a.pushabs(arr)
            a.pushabs(idx_slot)
            a.index()
            a.op(6)
        return f

    def h(value):
        return lambda: a.pushh(value)

    def redraw():
        for i in range(NROWS):
            a.pushh(LABELS[i]); a.pushi(i); call(G, N_LABEL, 1, keep=True); call(4, 15, 2)
            a.pushh(VALUE_OBJS[i]); a.pushi(i); call(G, N_VALUE, 1, keep=True); call(4, 15, 2)

    def result(k):
        a.pushi(k)
        call(G, N_RESULT, 1, keep=True)

    # ---------------- init ----------------
    for slot in (S_EXIT, S_RETURN):
        a.pushi(0)
        a.stabs(slot)
    call(G, N_BEGIN, 0, keep=True)
    a.stabs(S_NEW)
    a.pushh(PAGE_GENERAL); call(4, 2, 1)
    a.pushh(PAGE_ROWS_LAYER); call(4, 5, 1)
    a.pushh(NAVBAR_CLEAR); a.pushi(0); a.pushnil(); call(2, 5, 3)
    a.pushh(NAVBAR_BUTTONS); a.pushi(0)
    a.pushi(0); a.pushh_raw(TXT_SELECT); a.pushi(6); a.pushh_raw(TXT_CONFIRM)
    a.pushi(2); a.pushh_raw(TXT_BACK); a.array(6)
    call(2, 5, 3)
    a.pushh(NAVBAR_EXTRA); a.pushi(0); a.pushi(0); a.pushnil(); a.array(2); call(2, 5, 3)
    # The fifth row: shown on GENERAL (five rows), hidden on the four-row lists
    five = a.label()
    shown = a.label()
    call(G, N_ROWS, 0, keep=True); a.pushi(5); a.op(20); a.jt(five)
    for obj in (ROW5_BAR, ROW5_VALUES):
        a.pushh(obj); call(4, 5, 1)
    a.jmp(shown)
    a.here(five)
    for obj in (ROW5_BAR, ROW5_VALUES):
        a.pushh(obj); call(4, 4, 1)
    a.here(shown)
    const_array(S_ROWS, ROWS + [ROW5_VALUES])
    const_array(S_CUR, CURSOR_KEYS[:4])
    # (the fifth value row is a copy of the fourth: the same highlight keys)
    const_array(S_HLA, [HL_A[r][0] for r in range(4)] + [HL_A[3][0]])
    const_array(S_HLB, [HL_B[r][0] for r in range(4)] + [HL_B[3][0]])
    a.pushh(TITLE); call(G, N_TITLE, 0, keep=True); call(4, 15, 2)
    redraw()
    # Cursor to the starting row, rows at value 0 (highlighted: the cursor row).
    def cursor_key(k):
        def f():
            a.pushi(k)
            call(G, N_CURSOR_KEY, 1, keep=True)
        return f
    anim(h(CURSOR), h(CURSOR_INTRO), cursor_key(2), loop=1)
    for r in range(4):
        anim(h(ROWS[r]), h(INIT_A[r][0]), h(INIT_B[r][0]))
    anim(h(ROW5_VALUES), h(INIT_A[3][0]), h(INIT_B[3][0]))
    # INIT_* highlight row 0; move the highlight if the cursor starts elsewhere.
    skip = a.label()
    a.pushabs(S_NEW); a.pushi(0); a.op(20); a.jt(skip)
    a.pushi(0); a.stabs(S_OLD)
    anim(at(S_ROWS, S_OLD), at(S_HLB, S_OLD), at(S_HLA, S_OLD))
    anim(at(S_ROWS, S_NEW), at(S_HLA, S_NEW), at(S_HLB, S_NEW))
    a.here(skip)

    # ---------------- main loop ----------------
    loop = a.here("loop")
    a.pushabs(S_EXIT)
    a.jt("done")
    a.pushh_raw(INPUT)
    a.native(3, 6, 1)  # event (kept on the stack until the end of the frame)
    for code, ev in enumerate(EVENTS):
        nxt = a.label()
        a.dup(1); a.pushi(ev); a.op(20); a.jf(nxt)
        a.pushi(code); call(G, N_EVENT, 1)
        result(0); a.stabs(S_OLD)
        result(1); a.stabs(S_NEW)
        a.jmp("handle")
        a.here(nxt)
    a.jmp("frame_end")

    a.here("handle")
    no_redraw = a.label()
    result(2); a.jf(no_redraw)
    redraw()
    a.here(no_redraw)
    same = a.label()
    a.pushabs(S_OLD); a.pushabs(S_NEW); a.op(20); a.jt(same)
    anim(h(CURSOR), cursor_key(0), cursor_key(1))
    anim(at(S_ROWS, S_OLD), at(S_HLB, S_OLD), at(S_HLA, S_OLD))
    anim(at(S_ROWS, S_NEW), at(S_HLA, S_NEW), at(S_HLB, S_NEW))
    a.here(same)
    for code, name in ((1, "Move"), (2, "Select"), (3, "Back")):
        nos = a.label()
        result(4); a.pushi(code); a.op(20); a.jf(nos)
        sound(name)
        a.here(nos)
    # Restart dialog (a setting that needs a restart was saved): the game's YES / NO message box; YES restarts, NO puts those
    # settings back (C++) and the page stays
    nodialog = a.label()
    result(5); a.jf(nodialog)
    a.pushh_raw(MSG_YES_NO); a.setgh(MSGBOX_ID)
    for g, v in MSGBOX_FLAGS:
        a.pushi(v); a.setgh(g)
    wait = a.here("dialog_wait")
    waited = a.label()
    a.pushgh(MSGBOX_ID); a.jf(waited)
    a.pushi(0); a.yield_()
    a.jmp(wait)
    a.here(waited)
    declined = a.label()
    a.pushgh(MSGBOX_CHOICE); a.pushi(1); a.op(20); a.jf(declined)
    call(G, N_RESTART, 0)
    a.jmp(nodialog)
    a.here(declined)
    call(G, N_RESTART_CANCEL, 0)
    redraw()
    a.here(nodialog)
    noexit = a.label()
    result(3); a.jf(noexit)
    a.pushi(1); a.stabs(S_EXIT)
    a.here(noexit)

    a.here("frame_end")
    # Per-frame work of the C++ side (key capture); redraw when it asks
    no_frame_redraw = a.label()
    call(G, N_FRAME, 0, keep=True); a.jf(no_frame_redraw)
    redraw()
    a.here(no_frame_redraw)
    # Wait for the next frame: yield consumes its operand; then drop the event.
    a.pushi(0)
    a.yield_()
    a.pop()
    a.jmp(loop)

    a.here("done")
    a.pushi(1)
    a.stabs(S_RETURN)
    a.pushh(NAVBAR_CLEAR); a.pushi(0); a.pushnil(); call(2, 5, 3)
    a.end()

    # ---------------- Exit (called when the script is stopped) ----------------
    a.here("exit")
    restore = [(TITLE, TITLE_ORIG)] + list(zip(LABELS, LABELS_ORIG)) + \
        list(zip(VALUE_OBJS, VALUE_ORIG))
    for obj, orig in restore:
        a.pushh(obj)
        a.pushh(orig)
        call(4, 15, 2)
    for obj in (ROW5_BAR, ROW5_VALUES):
        a.pushh(obj); call(4, 5, 1)
    a.pushh(PAGE_GENERAL)
    call(4, 3, 1)
    a.pushabs(S_RETURN)
    a.jf("exit_done")
    call(G, N_RETURN_CURSOR, 0, keep=True)  # VIDEO_ITEM for VIDEO
    a.setgh(SETTINGS_CURSOR)
    call(G, N_RETURN_SCRIPT, 0, keep=True)  # SCRIPT_SETTINGS for VIDEO
    a.pushh_raw(0)
    call(3, 1, 2)
    a.here("exit_done")
    a.pushnil()
    a.ret()

    return module(a, {"Exit": "exit"}, NSLOTS, "sst:video.smos")


def main():
    blob = build()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "menu",
                       "graphics_script.inc")
    lines = ["// Generated by tools/gen_graphics_script.py - do not edit.",
             f"// {len(blob)} bytes: replacement for the game's \"video\" script.",
             "static const uint8_t kGraphicsScript[] = {"]
    for i in range(0, len(blob), 16):
        lines.append("    " + ", ".join(f"0x{b:02X}" for b in blob[i:i + 16]) + ",")
    lines.append("};")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print(f"wrote {out} ({len(blob)} bytes)")
    return blob


if __name__ == "__main__":
    main()
