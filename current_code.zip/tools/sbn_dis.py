#!/usr/bin/env python3
"""Disassembler for Sega Superstars Tennis front-end scripts (fescripts.sbn).

  python tools/sbn_dis.py fescripts.sbn --list
  python tools/sbn_dis.py fescripts.sbn options_general [video ...]
  python tools/sbn_dis.py fescripts.sbn options_general --names default.xex.bin --text SSTMainMenu_EN.DAT

Archive (big-endian): u32 count, 16 bytes, then count x 0x1C-byte entries
{u32 name hash, u32 name offset, u32 module offset, 16 zero bytes}. Module
layout and opcodes: tools/sbn_asm.py and claude/ingame-menu-re.md. Hashes are
lookup2 (initval 0x04C11DB7); --names hashes every printable string of a file
(e.g. the decrypted xex image) to name them, --text adds the strings of a
SumoTool _EN.DAT text table. Extracted game files stay out of git.
"""

import argparse
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sbn_asm import jhash  # noqa: E402

# name, operand format (b u8, h i16, H u16, i i32, I hash, f f32, s c-string)
OPS = {
    0x00: ("end", ""), 0x01: ("pushi", "i"), 0x02: ("pushh", "I"), 0x03: ("pushf", "f"),
    0x04: ("pushs", "s"), 0x05: ("pushs_rel", "h"), 0x06: ("dup", "i"), 0x07: ("dup", "b"),
    0x08: ("dup", "h"), 0x09: ("pushg", "H"), 0x0A: ("pushl", "i"), 0x0B: ("pushl", "b"),
    0x0C: ("pushl", "h"), 0x0D: ("op", "b"), 0x0E: ("put", "i"), 0x0F: ("put", "b"),
    0x10: ("put", "h"), 0x11: ("nop", ""), 0x12: ("native", "bH"), 0x13: ("jt", "h"),
    0x14: ("jf", "h"), 0x15: ("jmp", "h"), 0x16: ("print", "b"), 0x17: ("push0", ""),
    0x18: ("pop", ""), 0x19: ("popn", "b"), 0x1A: ("call", "bi"), 0x1B: ("ret", ""),
    0x1C: ("retn", "bi"), 0x1D: ("yield", ""), 0x1E: ("op1e", ""), 0x1F: ("op1f", ""),
    0x20: ("typeof", ""), 0x21: ("nop", ""), 0x22: ("array", "I"), 0x23: ("index", ""),
    0x24: ("callslot", "bh"), 0x25: ("dbg", ""), 0x26: ("dbgline", "i"), 0x27: ("stabs", "h"),
    0x28: ("callabs", "bh"), 0x29: ("pushabs", "h"), 0x2A: ("op2a", ""), 0x2B: ("pushstr", "s"),
    0x2C: ("pushstr_rel", "h"), 0x2D: ("setgh", "I"), 0x2E: ("callgh", "bI"), 0x2F: ("pushgh", "I"),
    0x30: ("method", "bI"), 0x31: ("pushnil", ""), 0x32: ("native", "bHhh"), 0x33: ("yield", "hh"),
    0x34: ("call", "bihh"), 0x35: ("retn", "bii"),
}
UNARY = {2: "tofloat", 3: "toint", 4: "tohash", 5: "tostr", 6: "hash", 7: "not"}
BINARY = {9: "mul", 10: "div", 12: "add", 13: "sub", 16: "lt", 18: "gt", 19: "ge", 20: "eq", 21: "ne"}


def scripts(data):
    n = struct.unpack_from(">I", data, 0)[0]
    ents = []
    for i in range(n):
        h, no, mo = struct.unpack_from(">III", data, 0x14 + 0x1C * i)
        ents.append((mo, data[no:data.index(b"\0", no)].decode("latin1"), h))
    ents.sort()
    out = {}
    for j, (mo, name, h) in enumerate(ents):
        end = ents[j + 1][0] if j + 1 < len(ents) else len(data)
        out[name] = data[mo:end]
    return out


def text_table(data):
    """{id: string} from a SumoTool _xx.DAT (TEXT chunk)."""
    out = {}
    o = 0
    while o + 16 <= len(data):
        tag = data[o:o + 4]
        size = struct.unpack_from(">I", data, o + 4)[0]
        if tag == b"TEXT":
            b = o + 16
            n = struct.unpack_from(">I", data, b + 8)[0]
            for i in range(n):
                h, off = struct.unpack_from(">II", data, b + 12 + 8 * i)
                e = data.index(b"\0", b + off)
                out.setdefault(h, data[b + off:e].decode("utf-8", "replace"))
        if not size:
            break
        o += size
    return out


def disassemble(mod, names):
    hdr = struct.unpack_from(">8I", mod, 0)
    code, functab = hdr[0], hdr[1]
    nf = struct.unpack_from(">I", mod, functab)[0]
    funcs = {code + struct.unpack_from(">I", mod, functab + 8 + 8 * i)[0]:
             struct.unpack_from(">I", mod, functab + 4 + 8 * i)[0] for i in range(nf)}
    print(f"; slots {hdr[6]}, functions " +
          ", ".join(f"{names.get(h, f'#{h:08x}')}@{o:05x}" for o, h in sorted(funcs.items())))
    pc = code
    while pc < functab:
        if pc in funcs:
            print(f"\n{names.get(funcs[pc], f'#{funcs[pc]:08x}')}:")
        op = mod[pc]
        at = pc
        pc += 1
        if op not in OPS:
            print(f"{at:05x}: ?? {op:02x}")
            break
        name, fmt = OPS[op]
        args = []
        for c in fmt:
            if c == "b":
                args.append(str(mod[pc])); pc += 1
            elif c in "hH":
                v = struct.unpack_from(">h" if c == "h" else ">H", mod, pc)[0]; pc += 2
                args.append(v)
            elif c == "i":
                args.append(struct.unpack_from(">i", mod, pc)[0]); pc += 4
            elif c == "I":
                h = struct.unpack_from(">I", mod, pc)[0]; pc += 4
                args.append(names.get(h, f"#{h:08x}"))
            elif c == "f":
                args.append(f"{struct.unpack_from('>f', mod, pc)[0]:g}"); pc += 4
            elif c == "s":
                e = mod.index(b"\0", pc)
                args.append(repr(mod[pc:e].decode("latin1"))); pc = e + 1
        if op in (0x13, 0x14, 0x15):
            args = [f"-> {pc + args[0]:05x}"]
        elif op in (0x1A, 0x34):
            args[1] = f"-> {pc + args[1]:05x}"
        elif op in (0x12, 0x32):
            args[1] = f"{args[1] >> 8}:{args[1] & 0xFF}"
        elif op == 0x0D:
            o = int(args[0])
            args = [UNARY.get(o, BINARY.get(o, f"op{o}"))]
        print(f"{at:05x}: {name} " + " ".join(str(a) for a in args))
        if op == 0x00 and pc >= functab:
            break


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sbn")
    ap.add_argument("scripts", nargs="*")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--names", action="append", default=[], help="file whose strings name hashes")
    ap.add_argument("--text", action="append", default=[], help="SumoTool _xx.DAT text table")
    a = ap.parse_args()
    data = open(a.sbn, "rb").read()
    mods = scripts(data)
    names = {jhash(n): n for n in mods}
    names[jhash("Exit")] = "Exit"
    for path in a.names:
        for m in re.finditer(rb"[\x20-\x7e]{2,}", open(path, "rb").read()):
            s = m.group().decode()
            for t in [s] + re.split(r"[^A-Za-z0-9_]+", s):
                if len(t) >= 2:
                    names.setdefault(jhash(t), t)
    for path in a.text:
        for h, s in text_table(open(path, "rb").read()).items():
            names.setdefault(h, "TXT" + repr(s[:40]))
    if a.list or not a.scripts:
        for n, m in mods.items():
            print(f"{jhash(n):08x} {len(m):6d} {n}")
        return
    for n in a.scripts:
        print(f"; ===== {n} =====")
        disassemble(mods[n], names)


if __name__ == "__main__":
    main()
