#!/usr/bin/env python3
"""Extract files from Sega Superstars Tennis (Xbox 360) RESOURCE.PAC.

RESOURCE.PAC layout (big-endian):
  0x00 u32 0 (next archive), 0x04 u32 0, 0x08 u32 data base (0x00800000),
  0x0C u32 entry count, then count x 16-byte entries sorted by hash:
  { u32 hash, u32 offset (absolute), u32 size, u32 size (again) }.
  Data is stored raw (no compression).

Entries are keyed by a hash of the full path the game asks for, which is
"game:\\" + path. The hash walks the string from the LAST character to the
first: a-z are uppercased, '/' becomes '\\', and h = h * 0x83 + (signed char)c
(32-bit). See sub_821B6D38 in the xex.

The archive has no file names, so this tool generates candidate names (the
SumoTool front-end scenes, known from the PC/Mac release) and keeps the ones
present. Everything else can be dumped by hash with --all.

Examples (Windows):
  python tools\\pac_extract.py "D:\\SST\\RESOURCE.PAC" --list
  python tools\\pac_extract.py "D:\\SST\\RESOURCE.PAC" --menu --zip sst_menu_files.zip
  python tools\\pac_extract.py "D:\\SST\\RESOURCE.PAC" --out pac_out --scenes PauseMenu MainMenu
  python tools\\pac_extract.py "D:\\SST\\RESOURCE.PAC" --out pac_out --all
  python tools\\pac_extract.py "D:\\SST\\RESOURCE.PAC" --out pac_out --path "Resource\\Foo\\Bar.dat"

Extracted files are game data: keep them out of git.
"""

import argparse
import os
import struct
import sys
import zipfile

# SumoTool scene folder -> scene file stems (from the Mac/PC Resource\SSTSumoTool tree).
SCENES = {
    "ArcadeIntro": ["ArcadeIntro"],
    "BallGameHuds": ["BGHuds"],
    "BallGames": ["BallGames"],
    "Challenge": ["ChallSel"],
    "ChallengeIntro": ["ChallengeIntro", "ChallengeIntro43"],
    "CharSelect": ["CharSelect"],
    "Credits": ["Credits"],
    "ErrorMsgs": ["ErrorMsgs"],
    "Global": ["Global"],
    "HiScore": ["HiScore"],
    "Hud": ["Hud"],
    "HudIcons": ["HudIcons"],
    "Ladder": ["Ladder"],
    "Leaderboards": ["Leaderboards"],
    "Loading": [],  # stems filled in below
    "LoadingAnim": ["LoadingAnim"],
    "Lobby": ["Lobby"],
    "MCMsgs": ["MCMsgs"],
    "MainMenu": ["SSTMainMenu", "SSTMainMenu43"],
    "MsgBox": ["MsgBox"],
    "NameEntry": ["NameEntry"],
    "OnlinePopup": ["OnlinePopup"],
    "PauseMenu": ["PauseMenu"],
    "PosSelect": ["PosSelect"],
    "Results": ["Results"],
    "SpectatorHud": ["SpecHud", "SpecHud43"],
    "StarBg": ["StarBg", "StarBg43"],
    "StartScreen": ["StartScreen"],
    "TitleSequence": ["TitleSequence"],
    "TournamentChart": ["TournChart"],
    "Tv": ["Tv"],
    "Video": ["Video"],
    "WhtFade": ["WhtFade"],
}
# Loading screens: Bg_<area>loading[43] plus the generic Loading scene.
LOADING_CODES = ["cc", "hd", "js", "mb", "pu", "sh", "so", "vc"]
SCENES["Loading"] = [f"Bg_{c}loading{s}" for c in LOADING_CODES for s in ("", "43")] + ["Loading", "Loading43"]

LANGS = ["", "_EN", "_FR", "_GE", "_IT", "_JP", "_SP", "_US"]
EXTS = ["GPU", "DAT", "REL"]
SUMO = "Resource\\SSTSumoTool"

# What the in-game graphics menu work needs.
MENU_SCENES = ["PauseMenu", "MainMenu", "Global", "MsgBox", "MCMsgs"]
MENU_LANGS = ["", "_EN", "_US"]
# Scene folders with a separate 4:3 layout (<Stem>43), plus the main menu.
ASPECT_SCENES = ["MainMenu", "StarBg", "Loading", "ChallengeIntro", "SpectatorHud"]


def pac_hash(path):
    h = 0
    for ch in reversed("game:\\" + path.lstrip("\\/")):
        c = ord(ch)
        if 0x61 <= c <= 0x7A:
            c -= 0x20
        elif c == 0x2F:
            c = 0x5C
        c &= 0xFF
        if c >= 0x80:
            c -= 0x100
        h = (h * 0x83 + c) & 0xFFFFFFFF
    return h


class Pac:
    def __init__(self, path):
        self.f = open(path, "rb")
        head = self.f.read(16)
        _, _, base, count = struct.unpack(">IIII", head)
        if count == 0 or count > 1_000_000:
            sys.exit(f"{path}: does not look like RESOURCE.PAC (entry count {count})")
        raw = self.f.read(16 * count)
        self.entries = {}
        for i in range(count):
            h, off, size, size2 = struct.unpack_from(">IIII", raw, 16 * i)
            self.entries[h] = (off, size)
        self.base = base
        self.file_size = os.path.getsize(path)

    def read(self, h):
        off, size = self.entries[h]
        self.f.seek(off)
        return self.f.read(size)


def scene_candidates(scenes, langs):
    for folder in scenes:
        for stem in SCENES[folder]:
            for lang in langs:
                for ext in EXTS:
                    yield f"{SUMO}\\{folder}\\{stem}{lang}.{ext}"


def known_names(pac):
    names = {}
    cands = list(scene_candidates(SCENES, LANGS)) + [f"{SUMO}\\fescripts.sbn", "RESOURCE.PAC"]
    for p in cands:
        h = pac_hash(p)
        if h in pac.entries and h not in names:
            names[h] = p
    return names


def guess_ext(data):
    m = data[:4]
    if m == b"DDS ":
        return ".dds"
    if m == b"RIFF":
        return ".wav"
    if m[:3] == b"XMA" or m == b"XWB" or m == b"WBND":
        return ".xwb"
    if m == b"XPR2":
        return ".xpr"
    return ".bin"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pac", help="path to RESOURCE.PAC")
    ap.add_argument("--out", default="pac_out", help="output folder (default pac_out)")
    ap.add_argument("--list", action="store_true", help="list named entries and a summary, extract nothing")
    ap.add_argument("--menu", action="store_true",
                    help="front-end files for the graphics menu work: fescripts.sbn + "
                         + ", ".join(MENU_SCENES) + " (base, _EN, _US)")
    ap.add_argument("--scenes", nargs="*", default=[], help="SumoTool scene folders to extract (all languages)")
    ap.add_argument("--aspect", action="store_true",
                    help="scenes the game has separate 4:3 layouts for (the aspect-ratio work): "
                         + ", ".join(ASPECT_SCENES) + " (base, _EN)")
    ap.add_argument("--langs", nargs="*",
                    help="languages for --scenes: base EN FR GE IT JP SP US (default: all)")
    ap.add_argument("--sumotool", action="store_true", help="every SumoTool scene file + fescripts.sbn")
    ap.add_argument("--path", nargs="*", default=[], help="extra paths relative to game:\\ (e.g. Resource\\X\\Y.dat)")
    ap.add_argument("--all", action="store_true", help="everything; unnamed entries go to _unnamed\\<hash>.<ext>")
    ap.add_argument("--zip", help="write the selected files into this zip instead of a folder")
    a = ap.parse_args()

    pac = Pac(a.pac)
    names = known_names(pac)
    print(f"{a.pac}: {len(pac.entries)} entries, {pac.file_size} bytes, {len(names)} named by this tool")

    if a.list:
        for h, p in sorted(names.items(), key=lambda kv: kv[1].lower()):
            off, size = pac.entries[h]
            print(f"  {h:08X} {off:12d} {size:10d}  {p}")
        unnamed = sum(1 for h in pac.entries if h not in names)
        print(f"{unnamed} entries have no known name")
        return

    sel = {}  # hash -> output relative path
    for p in a.path:
        h = pac_hash(p)
        if h in pac.entries:
            sel[h] = p
        else:
            print(f"not in PAC: {p}")
    scenes = list(a.scenes)
    langs = LANGS
    if a.langs:
        langs = ["" if l.lower() == "base" else "_" + l.upper() for l in a.langs]
    if a.sumotool or a.all:
        scenes = list(SCENES)
    for s in scenes:
        if s not in SCENES:
            sys.exit(f"unknown scene folder {s}; known: {', '.join(SCENES)}")
    if a.aspect:
        for p in scene_candidates(ASPECT_SCENES, ["", "_EN"]):
            h = pac_hash(p)
            if h in pac.entries:
                sel[h] = p
    if a.menu:
        for p in scene_candidates(MENU_SCENES, MENU_LANGS):
            h = pac_hash(p)
            if h in pac.entries:
                sel[h] = p
    for p in scene_candidates(scenes, langs):
        h = pac_hash(p)
        if h in pac.entries:
            sel[h] = p
    if a.menu or a.aspect or a.sumotool or a.all or scenes:
        p = f"{SUMO}\\fescripts.sbn"
        if pac_hash(p) in pac.entries:
            sel[pac_hash(p)] = p
    if a.all:
        for h in pac.entries:
            if h not in sel:
                sel[h] = names.get(h) or f"_unnamed\\{h:08X}"
    if not sel:
        sys.exit("nothing selected (use --menu, --aspect, --scenes, --sumotool, --path or --all)")

    zf = zipfile.ZipFile(a.zip, "w", zipfile.ZIP_DEFLATED) if a.zip else None
    total = 0
    for h, rel in sorted(sel.items(), key=lambda kv: kv[1].lower()):
        data = pac.read(h)
        if rel.startswith("_unnamed"):
            rel += guess_ext(data)
        rel = rel.replace("\\", "/")
        if zf:
            zf.writestr(rel, data)
        else:
            dst = os.path.join(a.out, *rel.split("/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "wb") as f:
                f.write(data)
        total += len(data)
    if zf:
        zf.close()
        print(f"wrote {len(sel)} files ({total} bytes) to {a.zip} ({os.path.getsize(a.zip)} bytes zipped)")
    else:
        print(f"wrote {len(sel)} files ({total} bytes) to {a.out}")


if __name__ == "__main__":
    main()
