"""Generate extended loading-screen backgrounds for ultrawide aspect ratios.

The 16:9 court loading backgrounds (Resource\\SSTSumoTool\\Loading\\Bg_<court>loading)
are 1280x720 pictures. For screens wider than 16:9 this script paints new
artwork beyond their left and right edges (up to 32:9: 640 px per side),
from each picture itself:

  - image quilting (patterns, line art, scenery): pieces of the picture that
    continue what is at its edge, joined along their least visible seams;
  - repeating patterns (checkerboard): continued with the pattern's period;
  - the pink swirl: its rays continued around their centre;
  - plain gradients (target background): the background colour carried on.

Output, per court, in --out (default: wide_backgrounds next to this repo's
build output - pass the folder that holds sst_rematch.exe):
  Bg_<court>loading_left.bmp   656x720: 640 px of new art + the picture's first 16 columns
  Bg_<court>loading_right.bmp  656x720: the picture's last 16 columns + 640 px of new art
  Bg_<court>loading_preview.png  the whole 2560x720 result, for a look

The game uses these files when they are there (VIDEO > ASPECT RATIO wider
than 16:9); otherwise it mirrors the picture. The BMPs can be edited or
replaced with your own artwork (same sizes; keep the 16 overlap columns).
They are made from your copy of the game: keep them out of the repository.

Needs: numpy, opencv-python (pip install numpy opencv-python).

  python tools\\wide_backgrounds.py "D:\\SST\\RESOURCE.PAC" --out "D:\\SST\\out\\win-amd64-release\\wide_backgrounds"
"""

import argparse
import os
import struct
import sys

import numpy as np

try:
    import cv2
except ImportError:
    sys.exit("needs opencv-python: pip install numpy opencv-python")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pac_extract import Pac, pac_hash  # noqa: E402

EXT = 640      # new columns per side (32:9 at 720 lines)
OVERLAP = 16   # picture columns kept in each side file (the game's inset)

# --- SumoTool scene / texture reading ----------------------------------------------------


def chunks(d):
    o = 0
    while o + 16 <= len(d):
        tag = d[o:o + 4]
        if not tag.strip(b"\0"):
            break
        size, dsize = struct.unpack_from(">II", d, o + 4)
        yield tag.decode("latin1"), o + 16, dsize
        if size == 0:
            break
        o += size


def background_texture(dat):
    """(page data offset, page w, page h, format, u0, v0, u1, v1) of the scene's
    largest texture (the full-screen background)."""
    for tag, b, ds in chunks(dat):
        if tag != "PTEX":
            continue
        n, pages, off = struct.unpack_from(">3I", dat, b)
        best = None
        for i in range(n):
            e = b + 12 + 40 * i
            uv = struct.unpack_from(">8f", dat, e + 4)
            page = struct.unpack_from(">I", dat, e + 36)[0]
            area = abs(uv[2] - uv[0]) * abs(uv[5] - uv[1])
            if best is None or area > best[0]:
                best = (area, uv, page)
        _, uv, page = best
        hoff, goff = struct.unpack_from(">II", dat, b + off + 8 * page)
        fc = struct.unpack_from(">6I", dat, b + hoff + 28)
        fmt = fc[1] & 0x3F
        w = (fc[2] & 0x1FFF) + 1
        h = ((fc[2] >> 13) & 0x1FFF) + 1
        return goff, w, h, fmt, uv[0], uv[1], uv[2], uv[5]
    raise ValueError("no textures")


def tiled_offset(x, y, pitch, bpb_log2):
    pitch = (pitch + 31) & ~31
    macro = ((x >> 5) + (y >> 5) * (pitch >> 5)) << (bpb_log2 + 7)
    micro = ((x & 7) + ((y & 0xE) << 2)) << bpb_log2
    offset = macro + ((micro & ~0xF) << 1) + (micro & 0xF) + ((y & 1) << 4)
    return (((offset & ~0x1FF) << 3) + ((y & 16) << 7) + ((offset & 0x1C0) << 2)
            + (((((y & 8) >> 2) + (x >> 3)) & 3) << 6) + (offset & 0x3F))


def decode_dxt3_region(gpu, base, page_w, x0, y0, w, h):
    """BGR (h x w x 3, uint8) of a region of a tiled, 8in16 DXT3 page."""
    bw = (page_w + 3) // 4
    bx0, by0 = x0 // 4, y0 // 4
    nbx, nby = (x0 + w + 3) // 4 - bx0, (y0 + h + 3) // 4 - by0
    raw = np.zeros((nby, nbx, 16), np.uint8)
    buf = np.frombuffer(gpu, np.uint8)
    for j in range(nby):
        for i in range(nbx):
            o = base + tiled_offset(bx0 + i, by0 + j, bw, 4)
            if o + 16 <= len(buf):
                raw[j, i] = buf[o:o + 16]
    raw = raw.reshape(nby, nbx, 8, 2)[..., ::-1].reshape(nby, nbx, 16)  # 8in16
    c0 = raw[..., 8].astype(np.uint32) | (raw[..., 9].astype(np.uint32) << 8)
    c1 = raw[..., 10].astype(np.uint32) | (raw[..., 11].astype(np.uint32) << 8)
    idx = (raw[..., 12].astype(np.uint32) | (raw[..., 13].astype(np.uint32) << 8)
           | (raw[..., 14].astype(np.uint32) << 16) | (raw[..., 15].astype(np.uint32) << 24))

    def rgb(c):
        return np.stack([((c >> 11) & 31) * 255.0 / 31, ((c >> 5) & 63) * 255.0 / 63,
                         (c & 31) * 255.0 / 31], -1)
    a, b = rgb(c0), rgb(c1)
    pal = np.stack([a, b, (2 * a + b) / 3, (a + 2 * b) / 3], 2)  # nby nbx 4 3
    sel = np.stack([(idx >> (2 * k)) & 3 for k in range(16)], -1)  # nby nbx 16
    px = np.take_along_axis(pal, sel[..., None].astype(np.int64), 2)  # nby nbx 16 3
    img = px.reshape(nby, nbx, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(nby * 4, nbx * 4, 3)
    img = img[y0 - by0 * 4:y0 - by0 * 4 + h, x0 - bx0 * 4:x0 - bx0 * 4 + w]
    return np.round(img[..., ::-1]).astype(np.uint8)


def court_picture(pac, court):
    stem = f"Resource\\SSTSumoTool\\Loading\\Bg_{court}loading"
    dat = pac.read(pac_hash(stem + ".dat"))
    gpu = pac.read(pac_hash(stem + ".gpu"))
    goff, pw, ph, fmt, u0, v0, u1, v1 = background_texture(dat)
    if fmt != 0x13:
        raise ValueError(f"unexpected texture format {fmt:#x}")
    x0, y0 = int(round(min(u0, u1) * pw)), int(round(min(v0, v1) * ph))
    x1, y1 = int(round(max(u0, u1) * pw)), int(round(max(v0, v1) * ph))
    return decode_dxt3_region(gpu, goff, pw, x0, y0, x1 - x0, y1 - y0)

# --- extension methods ---------------------------------------------------------------------


def _min_cut(err):  # h x o: True = take the new block
    h, o = err.shape
    E = err.copy()
    for y in range(1, h):
        prev = E[y - 1]
        left = np.r_[np.inf, prev[:-1]]
        right = np.r_[prev[1:], np.inf]
        E[y] += np.minimum(np.minimum(left, prev), right)
    mask = np.zeros_like(err, bool)
    x = int(np.argmin(E[-1]))
    for y in range(h - 1, -1, -1):
        mask[y, x:] = True
        if y:
            lo, hi = max(0, x - 1), min(o, x + 2)
            x = lo + int(np.argmin(E[y - 1, lo:hi]))
    return mask


def quilt_right(src, ext, block=64, overlap=16, tol=0.1, exclude=(), seed=1):
    """Image quilting (Efros & Freeman) of `ext` new columns right of src."""
    rng = np.random.default_rng(seed)
    H, W, C = src.shape
    out = np.zeros((H, W + ext, C), np.float32)
    out[:, :W] = src
    filled = np.zeros((H, W + ext), bool)
    filled[:, :W] = True
    step = block - overlap
    x = W - overlap
    while x < W + ext:
        y = 0
        while y < H:
            bh, bw = min(block, H - y), min(block, W + ext - x)
            tgt = out[y:y + bh, x:x + bw]
            m = np.repeat(filled[y:y + bh, x:x + bw, None], C, 2).astype(np.float32)
            res = cv2.matchTemplate(src, tgt, cv2.TM_SQDIFF, mask=m)
            res = np.nan_to_num(res, nan=1e30, posinf=1e30)
            for (ex0, ey0, ex1, ey1) in exclude:
                res[max(0, ey0 - bh):ey1, max(0, ex0 - bw):ex1] = 1e30
            ys, xs = np.where(res <= res.min() * (1 + tol) + 1e-3)
            if len(ys):
                k = rng.integers(len(ys))
                sy, sx = ys[k], xs[k]
            else:
                sy, sx = np.unravel_index(int(np.argmin(res)), res.shape)
            patch = src[sy:sy + bh, sx:sx + bw]
            take = np.ones((bh, bw), bool)
            ol = min(overlap, bw)
            if filled[y:y + bh, x:x + ol].all():
                take[:, :ol] &= _min_cut(((patch[:, :ol] - tgt[:, :ol]) ** 2).sum(2))
            if y > 0:
                ot = min(overlap, bh)
                take[:ot] &= _min_cut(((patch[:ot] - tgt[:ot]) ** 2).sum(2).T).T
            sel = take | ~filled[y:y + bh, x:x + bw]
            region = out[y:y + bh, x:x + bw]
            region[sel] = patch[sel]
            filled[y:y + bh, x:x + bw] = True
            y += step
        x += step
    return out[:, W:]


def quilt(img, side, block=64, overlap=16, tol=0.1, exclude=()):
    """Quilting at half resolution (exclude: source rectangles as fractions)."""
    small = cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA).astype(np.float32)
    h, w = small.shape[:2]
    ex = [(int(a * w), int(b * h), int(c * w), int(d * h)) for a, b, c, d in exclude]
    if side == "L":
        small = small[:, ::-1].copy()
        ex = [(w - c, b, w - a, d) for a, b, c, d in ex]
    r = quilt_right(small, EXT // 2, block, overlap, tol, ex)
    if side == "L":
        r = r[:, ::-1]
    return cv2.resize(r, (EXT, img.shape[0]), interpolation=cv2.INTER_CUBIC)


def periodic(img, side):
    """A horizontally repeating pattern, continued with its period (taken from
    the picture's left side; on the right, from the clean band that matches)."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    H, W = g.shape
    strip = g[:, :400]
    p = min(range(16, 200), key=lambda q: np.mean(np.abs(strip[:, :-q] - strip[:, q:])))
    f = img.astype(np.float32)
    if side == "L":
        return np.stack([f[:, (-(EXT - i)) % p] for i in range(EXT)], 1)
    tail = f[:, W - p:]
    o = min(range(p), key=lambda q: np.median(np.abs(f[:, q:q + p] - tail)))
    return np.stack([f[:, o + (i % p)] for i in range(EXT)], 1)


def plain(img, side, structure=None):
    """The background colour carried on (structure: mask of what is not background)."""
    H, W = img.shape[:2]
    if structure is None:
        structure = np.zeros((H, W), bool)
    mask = cv2.dilate(structure.astype(np.uint8) * 255, np.ones((7, 7), np.uint8))
    small = cv2.resize(img, (W // 4, H // 4), interpolation=cv2.INTER_AREA)
    ms = cv2.resize(mask, (W // 4, H // 4), interpolation=cv2.INTER_NEAREST)
    smooth = cv2.GaussianBlur(cv2.inpaint(small, ms, 9, cv2.INPAINT_TELEA), (0, 0), 6)
    smooth = cv2.resize(smooth, (W, H), interpolation=cv2.INTER_CUBIC).astype(np.float32)
    col = smooth[:, :1] if side == "L" else smooth[:, -1:]
    return np.repeat(col, EXT, 1)


def swirl(img, side):
    """Rays around a centre: each new pixel from a ring inside the picture, at
    the same angle (plus the rays' twist)."""
    H, W = img.shape[:2]
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)

    def ring(cx, cy, r, n=720):
        t = np.linspace(-np.pi, np.pi, n, endpoint=False)
        xs = (cx + r * np.cos(t)).astype(np.float32)[None]
        ys = (cy + r * np.sin(t)).astype(np.float32)[None]
        return cv2.remap(g, xs, ys, cv2.INTER_LINEAR)[0]
    best = None
    for cx in range(int(W * 0.55), int(W * 0.9), 10):
        for cy in range(int(H * 0.3), int(H * 0.7), 10):
            if min(cx, W - cx, cy, H - cy) < 250:
                continue
            a, b = ring(cx, cy, 120), ring(cx, cy, 240)
            sc = max(np.corrcoef(a, np.roll(b, k))[0, 1] for k in range(-40, 41, 2))
            if best is None or sc > best[0]:
                best = (sc, cx, cy)
    _, cx, cy = best
    a, b = ring(cx, cy, 120), ring(cx, cy, 240)
    k = max(range(-60, 61), key=lambda q: np.corrcoef(a, np.roll(b, q))[0, 1])
    twist = -k * (2 * np.pi / 720) / 120.0
    r0 = min(cx, W - 1 - cx, cy, H - 1 - cy) - 2
    xs = np.arange(-EXT, 0) if side == "L" else np.arange(W, W + EXT)
    yy, xx = np.meshgrid(np.arange(H, dtype=np.float32), xs.astype(np.float32), indexing="ij")
    dx, dy = xx - cx, yy - cy
    r = np.sqrt(dx * dx + dy * dy)
    t = np.arctan2(dy, dx)
    rs = np.minimum(r, r0)
    ts = t + twist * (r - rs)
    return cv2.remap(img.astype(np.float32), (cx + rs * np.cos(ts)).astype(np.float32),
                     (cy + rs * np.sin(ts)).astype(np.float32), cv2.INTER_LINEAR)


def target_structure(img):
    f = img.astype(np.float32)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    return ~((b > r + 25) & (np.abs(g - r) < 40) & (b < 200))


# Per court: how each side is extended.
RECIPES = {
    "cc": {"L": lambda i: quilt(i, "L"), "R": lambda i: quilt(i, "R")},   # ChuChu Rocket grid
    "hd": {"L": lambda i: quilt(i, "L"), "R": lambda i: quilt(i, "R")},   # Curien Mansion
    "js": {"L": lambda i: quilt(i, "L"), "R": lambda i: quilt(i, "R")},   # Jet Set Radio
    "pu": {"L": lambda i: quilt(i, "L"), "R": lambda i: quilt(i, "R")},   # Puyo Pop
    "mb": {"L": lambda i: plain(i, "L"), "R": lambda i: swirl(i, "R")},   # pink swirl
    "so": {"L": lambda i: periodic(i, "L"), "R": lambda i: periodic(i, "R")},  # checkerboard
    "vc": {"L": lambda i: plain(i, "L", target_structure(i)),               # Virtua Cop
           "R": lambda i: plain(i, "R", target_structure(i))},
    # Space Harrier: the logo is part of the picture - never copied.
    "sh": {"L": lambda i: quilt(i, "L", 96, 24, 0.02, [(0.03, 0.05, 0.5, 0.4)]),
           "R": lambda i: quilt(i, "R", 96, 24, 0.02, [(0.03, 0.05, 0.5, 0.4)])},
}
COURTS = ["cc", "hd", "js", "mb", "pu", "sh", "so", "vc"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pac", help="path to RESOURCE.PAC")
    ap.add_argument("--out", default="wide_backgrounds",
                    help="output folder: <folder with sst_rematch.exe>\\wide_backgrounds")
    ap.add_argument("--courts", nargs="*", default=COURTS, help="court codes (default: all)")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    pac = Pac(a.pac)
    for court in a.courts:
        name = f"Bg_{court}loading"
        print(f"{name}: reading", flush=True)
        pic = court_picture(pac, court)
        H, W = pic.shape[:2]
        print(f"{name}: painting {EXT} px per side ({W}x{H} picture)", flush=True)
        left = np.clip(RECIPES[court]["L"](pic), 0, 255).astype(np.uint8)
        right = np.clip(RECIPES[court]["R"](pic), 0, 255).astype(np.uint8)
        cv2.imwrite(os.path.join(a.out, name + "_left.bmp"),
                    np.concatenate([left, pic[:, :OVERLAP]], 1))
        cv2.imwrite(os.path.join(a.out, name + "_right.bmp"),
                    np.concatenate([pic[:, W - OVERLAP:], right], 1))
        cv2.imwrite(os.path.join(a.out, name + "_preview.png"), np.concatenate([left, pic, right], 1))
    print(f"done: {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()
